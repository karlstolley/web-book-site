The Rapid Prototyping Kit (RPK)
===============================

The Rapid Prototyping kit is a set of files for quickly building Web pages using
XHTML 1.0 Strict, Cascading Stylesheets (CSS), and JavaScript. It accompanies 
a book by Karl Stolley, titled _How to Design and Write Web Pages Today_
(Greenwood Press, 2011).


Licensing
=========

See the LICENSE.txt file.

